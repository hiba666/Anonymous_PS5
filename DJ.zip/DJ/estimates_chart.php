<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$u_name = $_POST['u_name'];
$amount_n = $_POST['amount_n'];
$amount_w = $_POST['amount_w'];
$amount_s = $_POST['amount_s'];



$salary_q =  "Select salary from expenditure where u_name = '$u_name'";
$salary = mysqli_query($conn, $salary_q);
if (FALSE === $salary) die("Select sum failed: ".mysqli_error);
$salary_row = mysqli_fetch_row($salary);
$salary_sum = $salary_row[0];



?>

<!DOCTYPE html>
<head>
<title>
Estimates
</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/noui/nouislider.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>



<body>
  <div class="container-contact100">
    <div class="wrap-contact100">

      <form class="contact100-form validate-form" method = "post" action = "stats.php">
        <span class="contact100-form-title">
          Estimated Expenses Analysis
        </span>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
        <canvas id="myChart"></canvas>
        <style>
        #myChart{
          position: relative;
          height: 300px;
          width: 400px;
          margin-top: 20px;
          left: 0%;
          margin-bottom: 20px;
        }
        </style>

  <script>
  var ctx = document.getElementById('myChart').getContext('2d');
  var chart = new Chart(ctx, {
      // The type of chart we want to create
      type: 'pie',
    			data: {
    				datasets: [{
    					data: [<?php echo $amount_n ?>,<?php echo $amount_w ?>, <?php echo $amount_s ?>],
              backgroundColor: ['red', 'orange', 'yellow'],
    					label: 'Dataset 1',
    				}],

    				labels: [
    					'Needs',
    					'Wants',
    					'Savings',
    				]
    			},

      // Configuration options go here
      options: {
          responsive:true,
         maintainAspectRatio: false,
      }
   });
   </script>
<script>
   function prompts(){
   if(<?php echo "$amount_s"?> >= <?php echo "$amount_w" ?>)
   {
     //alert("Invest smarter. Consult the chatbot");
     document.getElementById("message").innerHTML = "Invest smarter. Consult the chatbot";
   }

   if(<?php echo "$amount_s"?> <= <?php echo "$amount_w" ?>)
   {
     {

       document.getElementById("message").innerHTML = "Curb your expenses. Consult the chatbot";
     }
   }
 }
 window.onload = prompts;
 </script>
 <div class="wrap-input100 validate-input bg1" data-validate="Please Type Your Username" style="background-color: rgba(000,000,255,0.2); border-style: solid;">
 <h1 id = "message"></h1>
 </div>
 </body>
 </html>
