<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

h1
{
color:white;
font-family: comic sans MS;
font-size: 300%;
text-align: center;

}

#fin{
	position: relative;
	right: 700px;
	font-size: 25px;
	color:red;
}


h2
{
color:black;
font-family: comic sans MS;
font-size: 200%;
text-align: center;
}




.btn1{
font-size:50px;
font-family:verdana;
color:black;
  cursor: pointer;
  border-radius: 15px;
  text-align: center;
  padding: 16px 30px;
  border: none;
  margin-top:350px;

}
.btn1:hover{ background-color:black;
color:white;}
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  height: 120px;

}

li {
  float: right;
  height:25%;
}
#fin{
list-style-type: none;
	position: relative;
	right: 250px;
	font-size: 25px;
	color:red;
	font-family:verdana;
}
li a {
  display: block;
  color: white;
  text-align: center;
   font-size:25px;


  padding: 20px 20px;
  text-decoration: none;
}

li a:hover:not(.active) {

  background-color: #111;
}

.active {
  background-color: #4CAF50;
}


.header {
  width: 100%;
  color: white;
  background: black;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
  position:absolute;
height:7%;
}


table {
  margin-left:0px;
  margin-right:300px;
  margin-top:0px;
  margin-bottom:300px;


  border-collapse: collapse;
  width: 50%;
  border-radius: 25px;
  border:300px;
  background-color:url("bg1.jpg");
  position: absolute;
}

th, td {
  text-align: center;
  padding: 8px;
}

tr{background-color: #f2f2f2}

th {
  background-color:#3333cc;
  color: white;
}
body{
	background-image:url("bg3.jpg");
	background-color:#D3D3D3;
	background-repeat: no-repeat;
    background-size: cover;
	min-height: 50px;
	margin:0px;
	overflow-x:hidden;

}

input[type=text] {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border-color: black;
  text-size:18px;
}

</style>

<body>
<header class="header">

<ul>
	<img src="lo.jpg" alt="logo" style="height: 70px; position:relative; right:425px; bottom:20px;" />
  <li><a href="index.html">About us</a></li>
  <li><a href="index.html">Log out</a></li>
	<li><a href="index.html">Home</a></li>

  <li id="fin"><a href="" style="font-size:25px">FAMILY FINANCE MANAGER</a></li>
</ul>


</header>
<center>
<input type = "email" name="fam_email" style="width:800px; font-size:50px;" placeholder="Enter email of your family member">
&nbsp;&nbsp;<a href="mailto:yashdhage1@gmail.com?Subject=Group%20invite&body=Hi, I found this website
and thought you might like it http://f978a795.ngrok.io/DJ/regf.php" target="_top"><button class ="btn1"> Send Mail</button></a>
</center>
</div>

</body>
</html>


</body>
</html>
