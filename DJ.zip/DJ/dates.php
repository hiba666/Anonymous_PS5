<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$u_name = $_POST['u_name'];

$query =  "Select category, amount, date from expenditure_dates where u_name = '$u_name' order by date";

$result = mysqli_query($conn, $query);

    echo "<br><table> <tr><td>Category</td><td>Amount</td><td>Date</td></tr>";
    while($row = mysqli_fetch_assoc($result))
    {
        $category = $row['category'];
        $amount = $row['amount'];
        $date = $row['date'];
        if($amount<=500)
        {
          echo "<tr> <td>$category</td> <td>$amount </td> <td>$date</td> </tr>";
        }
        else
          {
            echo "<tr> <td>$category</td> <td><b>$amount</b></td> <td>$date</td> </tr>";
          }
    }




    echo "</table>";

?>

<html>
<head>
  <style>
  table,th,td{
    border: 2px;
    border-style: solid;
    border-radius: 5px;
    border-collapse: collapse;
    padding: 20px;
    width: 700px;
    margin-left: 5px;
    margin-right: 5px;
    position: relative;
    top:15%;
    left: 10%;

    }
td{
  background-color: rgba(000,000,255,0.2);
}



  h1{
    position: absolute;
    top: 5%;
    left:40%;
  }
  </style>



  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/noui/nouislider.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">


</head>
<body>
  <script>
    function colours(){

    }
  </script>
  <h1>Daily Expenses tracker:</h1>
  <style>
  h1{
    background-color: rgba(0,0,0,0.2);
    width: 100%;
    padding: 10px;
    left:0%;
    text-align: center;
    font-size: 50px;
  }
</style>
</body>
</html>
