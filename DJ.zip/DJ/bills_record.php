<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$u_name = $_POST['u_name'];

$query =  "Select category, due_date, days, amount from bills where u_name = '$u_name'";

$result = mysqli_query($conn, $query);

    echo "<br><table> <tr><td>Category</td><td>Due Date</td><td>Days remaining</td> <td> Amount </td></tr>";
    while($row = mysqli_fetch_assoc($result))
    {
        $category = $row['category'];
        $due_date = $row['due_date'];
        $days = $row['days'];
        $amount = $row['amount'];
        if($days<=10)
        {
          echo "<tr> <td>$category</td> <td>$due_date </td> <td><b>$days</b></td><td>$amount</td> </tr>";
        }
        else
          {
            echo "<tr> <td>$category</td> <td>$due_date </td> <td>$days</td><td>$amount</td> </tr>";
          }
    }




    echo "</table>";

?>

<html>
<head>
  <style>
  table,th,td{
    border: 2px;
    border-style: solid;
    border-radius: 5px;
    border-collapse: collapse;
    padding: 20px;
    width: 700px;
    margin-left: 5px;
    margin-right: 5px;
    position: relative;
    top:15%;
    left: 20%;

    }
td{
  background-color: rgba(000,000,255,0.2);
}



  h1{
    position: absolute;
    top: 5%;
    left:40%;
  }
  </style>



  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/noui/nouislider.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">


</head>
<body onload="myFunction()">
  <script>
function myFunction() {
  alert("Latest due bill is: rent. Expiring in: 1 days");
}
</script>
  <h1>Bills tracker:</h1>
  <style>
  h1{
    background-color: rgba(0,0,0,0.2);
    width: 100%;
    padding: 10px;
    left:0%;
    text-align: center;
    font-size: 50px;
  }
</style>
</body>
</html>
